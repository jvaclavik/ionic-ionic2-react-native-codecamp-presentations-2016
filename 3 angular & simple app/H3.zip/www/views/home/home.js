app.controller('HomeCtrl', function($scope, $state) {

});
