app.controller('MoviesListCtrl', function ($scope, $state, GlobalService, MoviesService, $ionicModal, $ionicPopup, $ionicListDelegate, $ionicSlideBoxDelegate) {
    $scope.data = MoviesService.data;
    $scope.form = {};


    $scope.order = 'title';


    $scope.showMovieAddModal = function () {
        $ionicModal.fromTemplateUrl('views/movies/movie-add.html', {
            scope: $scope,
            animation: 'slide-in-up'
        }).then(function (modal) {
            $scope.modal = modal;
            $scope.modal.show();
        });
    };

    $scope.movieAdd = function () {
        if($scope.form.title){
            $scope.data.movies.push({
                title: $scope.form.title
            });
            $scope.form = {};
            $scope.modal.hide();
        } else{
          alert("Please fill movie title")
        }
    };

    $scope.showHelp = function () {
        $ionicModal.fromTemplateUrl('views/help/help.html', {
            scope: $scope,
            animation: 'slide-in-up'
        }).then(function (modal) {
            $scope.modalHelp = modal;
            $scope.modalHelp.show();
        });
    };
    $scope.nextSlide = function () {
        $ionicSlideBoxDelegate.next();
    };

    $scope.hideHelp = function () {
        $scope.modal.hide();
    };


    $scope.movieRemove = function (title) {
        var confirmPopup = $ionicPopup.confirm({
            title: "Do you want delete this movie?",
            okType: "button-assertive"
        });

        confirmPopup.then(function (res) {
            if (res) {
                var movies = $scope.data.movies;
                for (var i = 0; i < movies.length; i++) {
                    if (movies[i].title == title)
                        movies.splice(i, 1);
                }
            }
            $ionicListDelegate.closeOptionButtons();
        });
    }
});