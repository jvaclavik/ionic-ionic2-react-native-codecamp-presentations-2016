var translations_cs = {
    "BASIC": {
        "YES": "Ano",
        "NO": "Ne"
    }
};