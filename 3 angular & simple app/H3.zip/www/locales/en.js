var translations_en = {
    "BASIC": {
        "YES": "Yes",
        "NO": "No"
    }
};